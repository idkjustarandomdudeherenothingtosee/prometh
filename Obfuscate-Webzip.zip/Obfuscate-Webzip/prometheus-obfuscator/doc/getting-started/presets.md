# Presets

The following table provides an overview over the presets

| name   | size   | speed   |
| ------ | ------ | ------- |
| Minify | tiny   | fastest |
| Weak   | small  | fast    |
| Medium | medium | medium  |
| Strong | huge   | slowest |
