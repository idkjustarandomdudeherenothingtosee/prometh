# Prometheus Lua Code Obfuscator

## Overview
A fully client-side web-based Lua code obfuscator powered by the Prometheus obfuscation engine running in the browser via Fengari (Lua 5.3 VM compiled to JavaScript). Features a professional IDE-like interface with Monaco Editor, configurable security presets, and a responsive design.

## Project Structure
```
/
├── index.html              # Main HTML page
├── index.css               # All styles
├── index.js                # Application logic (vanilla JS + Fengari integration)
├── fengari-web.js          # Fengari Lua VM (browser build)
├── lua-bundle.js           # Bundled Prometheus Lua modules for browser
├── build-lua-bundle.py     # Script to regenerate lua-bundle.js
├── server.py               # Simple static file server (no API needed)
├── prometheus-obfuscator/  # Lua obfuscation engine source
│   ├── cli.lua             # Command-line interface
│   ├── src/                # Core obfuscator source
│   └── ...
└── replit.md               # This file
```

## Architecture
- **Client-side only**: All obfuscation runs in the browser using Fengari
- **No backend API**: Server only serves static files
- **Bundled modules**: 39 Lua modules bundled into lua-bundle.js via package.preload
- **Lua 5.1 polyfills**: Includes compatibility shims for arg, newproxy, bit32, io stubs

## Features
- Monaco Editor for input/output code editing
- Four obfuscation presets (Weak, Medium, Strong, Maximum)
- Resizable split panels on desktop
- Tabbed interface on mobile
- Copy to clipboard and download functionality
- Sample code loader
- Keyboard shortcut (Ctrl+Enter) for obfuscation

## Presets
- **Weak**: Basic obfuscation (minification, string encryption)
- **Medium**: Variable renaming, control flow, anti-tamper
- **Strong**: Maximum protection with all available steps
- **Maximum**: Same as Strong (alias for UI)

## Development
To regenerate the Lua bundle after modifying Prometheus source:
```bash
python build-lua-bundle.py
```

## Recent Changes
- 2024-12-10: Migrated to fully client-side using Fengari (no Python backend dependency)
- 2024-12-10: Added Lua 5.1 compatibility polyfills for Lua 5.3 Fengari
- 2024-12-10: Consolidated to vanilla HTML/CSS/JS from React/TypeScript
